#pragma once

#include <sstream>
#include <iostream>
#include <string>
#include <regex>
#include <fstream>
#include "board.hpp"

namespace Chess5D {
  template<U8 Set, U8 Size, U16 L, U16 T>
  struct Chess {
    Board<Set> boards[L + 16][T + 32]{};
    TimelineInfo timelineInfo[L + 16]{};

    U8 whiteOrigIndex{ (L + 16) / 2 };
    U8 blackOrigIndex{ (L + 16) / 2 };
    U8 whiteNum{ 0 };
    U8 blackNum{ 0 };
    U8 whiteActiveNum{ 0 };
    U8 blackActiveNum{ 0 };

    template<bool White> _Compiletime void makeMove(const Move& move);
    template<bool White> _Compiletime void undoMove(const Move& move);
    template<bool White> _Compiletime void generateMoves(std::vector<Move>& moves);
    //template<bool White> _Compiletime void generateMovesets(std::vector<std::vector<Move>>& movesets);
    template<bool White> _Compiletime Move PGNtoMove(std::smatch matches);
    _Compiletime void importPGN(std::string PGN);
    _Compiletime void importFen(std::string fen);
    _Compiletime void printToFile(std::ofstream& file);

    _Compiletime Chess() {
      for (U16 i = 0; i < L + 16; ++i) timelineInfo[i].timeline = i;
    }
  };

  template<U8 Set, U16 T, bool White>
  _Compiletime U64 createMask(Board<Set>* brd) {
    constexpr U16 l1 = T, l2 = 2 * T, l3 = 3 * T, l4 = 4 * T, l5 = 5 * T, l6 = 6 * T, l7 = 7 * T;

    constexpr U512 notE = { Not<East>(), Not<East>(), Not<East>(), 0, Not<East>(), Not<East>(), Not<East>(), 0 };
    constexpr U512 notW = { Not<West>(), Not<West>(), Not<West>(), 0, Not<West>(), Not<West>(), Not<West>(), 0 };

    const U64 rook = brd->rooks(!White, true);
    const U64 bishop = brd->bishops(!White, true);
    const U64 unicorn = brd->unicorns(!White, true);
    const U64 dragon = brd->dragons(!White, true);

    const U512 center = _mm512_set_epi64(0, bishop, rook, bishop, rook, bishop, rook, bishop);
    const U512 orth = _mm512_set_epi64(0, unicorn, bishop, unicorn, bishop, unicorn, bishop, unicorn);
    const U512 diag = _mm512_set_epi64(0, dragon, unicorn, dragon, unicorn, dragon, unicorn, dragon);

    const U512 o1 = ~_mm512_set_epi64(0, (brd - l1 + 2)->board.occ, (brd - l1)->board.occ, (brd - l1 - 2)->board.occ,
      0, (brd + l1 + 2)->board.occ, (brd + l1)->board.occ, (brd + l1 - 2)->board.occ);
    const U512 o2 = ~_mm512_set_epi64(0, (brd - l2 + 4)->board.occ, (brd - l2)->board.occ, (brd - l2 - 4)->board.occ,
      0, (brd + l2 + 4)->board.occ, (brd + l2)->board.occ, (brd + l2 - 4)->board.occ);
    const U512 o3 = ~_mm512_set_epi64(0, (brd - l3 + 6)->board.occ, (brd - l3)->board.occ, (brd - l3 - 6)->board.occ,
      0, (brd + l3 + 6)->board.occ, (brd + l3)->board.occ, (brd + l3 - 6)->board.occ);
    const U512 o4 = ~_mm512_set_epi64(0, (brd - l4 + 8)->board.occ, (brd - l4)->board.occ, (brd - l4 - 8)->board.occ,
      0, (brd + l4 + 8)->board.occ, (brd + l4)->board.occ, (brd + l4 - 8)->board.occ);
    const U512 o5 = ~_mm512_set_epi64(0, (brd - l5 + 10)->board.occ, (brd - l5)->board.occ, (brd - l5 - 10)->board.occ,
      0, (brd + l5 + 10)->board.occ, (brd + l5)->board.occ, (brd + l5 - 10)->board.occ);
    const U512 o6 = ~_mm512_set_epi64(0, (brd - l6 + 12)->board.occ, (brd - l6)->board.occ, (brd - l6 - 12)->board.occ,
      0, (brd + l6 + 12)->board.occ, (brd + l6)->board.occ, (brd + l6 - 12)->board.occ);

    const U512 r1 = _mm512_set_epi64(0, (brd - l1 + 2)->royalty(White), (brd - l1)->royalty(White), (brd - l1 - 2)->royalty(White),
      0, (brd + l1 + 2)->royalty(White), (brd + l1)->royalty(White), (brd + l1 - 2)->royalty(White));
    const U512 r2 = _mm512_set_epi64(0, (brd - l2 + 4)->royalty(White), (brd - l2)->royalty(White), (brd - l2 - 4)->royalty(White),
      0, (brd + l2 + 4)->royalty(White), (brd + l2)->royalty(White), (brd + l2 - 4)->royalty(White));
    const U512 r3 = _mm512_set_epi64(0, (brd - l3 + 6)->royalty(White), (brd - l3)->royalty(White), (brd - l3 - 6)->royalty(White),
      0, (brd + l3 + 6)->royalty(White), (brd + l3)->royalty(White), (brd + l3 - 6)->royalty(White));
    const U512 r4 = _mm512_set_epi64(0, (brd - l4 + 8)->royalty(White), (brd - l4)->royalty(White), (brd - l4 - 8)->royalty(White),
      0, (brd + l4 + 8)->royalty(White), (brd + l4)->royalty(White), (brd + l4 - 8)->royalty(White));
    const U512 r5 = _mm512_set_epi64(0, (brd - l5 + 10)->royalty(White), (brd - l5)->royalty(White), (brd - l5 - 10)->royalty(White),
      0, (brd + l5 + 10)->royalty(White), (brd + l5)->royalty(White), (brd + l5 - 10)->royalty(White));
    const U512 r6 = _mm512_set_epi64(0, (brd - l6 + 12)->royalty(White), (brd - l6)->royalty(White), (brd - l6 - 12)->royalty(White),
      0, (brd + l6 + 12)->royalty(White), (brd + l6)->royalty(White), (brd + l6 - 12)->royalty(White));
    const U512 r7 = _mm512_set_epi64(0, (brd - l7 + 14)->royalty(White), (brd - l7)->royalty(White), (brd - l7 - 14)->royalty(White),
      0, (brd + l7 + 14)->royalty(White), (brd + l7)->royalty(White), (brd + l7 - 14)->royalty(White));

    U512 maskC = ((r1 | ((o1 & (r2 | ((o2 & (r3 | (o3 & ((r4 | (o4 & ((r5 | (o5 & ((r6 | (o6 & (r7)))))))))))))))))));
    U512 maskN = ((r1 | ((o1 & (r2 | ((o2 & (r3 | (o3 & ((r4 | (o4 & ((r5 | (o5 & ((r6 | (o6 & (r7) << 8))) << 8))) << 8))) << 8))) << 8))) << 8))) << 8;
    U512 maskE = ((r1 | ((o1 & (r2 | ((o2 & (r3 | (o3 & ((r4 | (o4 & ((r5 | (o5 & ((r6 | (o6 & (r7 & notE) << 1)) & notE) << 1)) & notE) << 1)) & notE) << 1)) & notE) << 1)) & notE) << 1)) & notE) << 1;
    U512 maskW = ((r1 | ((o1 & (r2 | ((o2 & (r3 | (o3 & ((r4 | (o4 & ((r5 | (o5 & ((r6 | (o6 & (r7 & notW) >> 1)) & notW) >> 1)) & notW) >> 1)) & notW) >> 1)) & notW) >> 1)) & notW) >> 1)) & notW) >> 1;
    U512 maskS = ((r1 | ((o1 & (r2 | ((o2 & (r3 | (o3 & ((r4 | (o4 & ((r5 | (o5 & ((r6 | (o6 & (r7) >> 8))) >> 8))) >> 8))) >> 8))) >> 8))) >> 8))) >> 8;
    U512 maskNE = ((r1 | ((o1 & (r2 | ((o2 & (r3 | (o3 & ((r4 | (o4 & ((r5 | (o5 & ((r6 | (o6 & (r7 & notE) << 9)) & notE) << 9)) & notE) << 9)) & notE) << 9)) & notE) << 9)) & notE) << 9)) & notE) << 9;
    U512 maskSE = ((r1 | ((o1 & (r2 | ((o2 & (r3 | (o3 & ((r4 | (o4 & ((r5 | (o5 & ((r6 | (o6 & (r7 & notE) >> 7)) & notE) >> 7)) & notE) >> 7)) & notE) >> 7)) & notE) >> 7)) & notE) >> 7)) & notE) >> 7;
    U512 maskSW = ((r1 | ((o1 & (r2 | ((o2 & (r3 | (o3 & ((r4 | (o4 & ((r5 | (o5 & ((r6 | (o6 & (r7 & notW) >> 9)) & notW) >> 9)) & notW) >> 9)) & notW) >> 9)) & notW) >> 9)) & notW) >> 9)) & notW) >> 9;
    U512 maskNW = ((r1 | ((o1 & (r2 | ((o2 & (r3 | (o3 & ((r4 | (o4 & ((r5 | (o5 & ((r6 | (o6 & (r7 & notW) << 7)) & notW) << 7)) & notW) << 7)) & notW) << 7)) & notW) << 7)) & notW) << 7)) & notW) << 7;

    const U64 royalty = (brd - 2)->royalty(White);

    maskC[3] = brd->pastMask.center = royalty | (brd - 2)->board.occ & (brd - 2)->pastMask.center;
    maskN[3] = brd->pastMask.north = royalty | (brd - 2)->board.occ & ((brd - 2)->pastMask.north) << 8;
    maskE[3] = brd->pastMask.east = royalty | (brd - 2)->board.occ & ((brd - 2)->pastMask.east & Not<East>()) << 1;
    maskS[3] = brd->pastMask.south = royalty | (brd - 2)->board.occ & ((brd - 2)->pastMask.south) >> 8;
    maskW[3] = brd->pastMask.west = royalty | (brd - 2)->board.occ & ((brd - 2)->pastMask.west & Not<West>()) >> 1;
    maskNE[3] = brd->pastMask.northeast = royalty | (brd - 2)->board.occ & ((brd - 2)->pastMask.northeast & Not<East>()) << 9;
    maskSE[3] = brd->pastMask.southeast = royalty | (brd - 2)->board.occ & ((brd - 2)->pastMask.southeast & Not<East>()) >> 7;
    maskSW[3] = brd->pastMask.southwest = royalty | (brd - 2)->board.occ & ((brd - 2)->pastMask.southwest & Not<West>()) >> 9;
    maskNW[3] = brd->pastMask.northwest = royalty | (brd - 2)->board.occ & ((brd - 2)->pastMask.northwest & Not<West>()) << 7;

    const U64 maskSlider = _mm512_reduce_or_epi64((center & maskC) | (orth & maskN) | (orth & maskE) | (orth & maskW) | (orth & maskS) | (diag & maskNE) | (diag & maskSE) | (diag & maskSW) | (diag & maskNW));

    U64 knight = brd->bitBoard(!White, Knight);
    U64 maskKnight = knight & ((brd + l1 - 4)->royalty(White) | (brd + l1 + 4)->royalty(White) | (brd + l2 - 2)->royalty(White) | (brd + l2 + 2)->royalty(White)
      | (brd - l1 - 4)->royalty(White) | (brd - l1 + 4)->royalty(White) | (brd - l2 - 2)->royalty(White) | (brd - l2 + 2)->royalty(White));
    const U64 royaltyKnightD1 = (brd - 2)->royalty(White) | (brd + l1)->royalty(White) | (brd - l1)->royalty(White);
    const U64 royaltyKnightD2 = (brd - 4)->royalty(White) | (brd + l2)->royalty(White) | (brd - l2)->royalty(White);
    Bitloop(knight) {
      const U8 sq = SquareOf(knight);
      maskKnight |= 1ull << sq & -((Lookup::Knight1Attacks[sq] & royaltyKnightD1 | Lookup::Knight2Attacks[sq] & royaltyKnightD2) != 0);
    }

    U64 king = brd->kings(!White, true);
    const U64 royaltyKing = (brd - 2)->royalty(White) | _mm512_reduce_or_epi64(r1);
    U64 maskKing = king & royaltyKing;
    Bitloop(king) {
      const U8 sq = SquareOf(king);
      maskKing |= 1ull << sq & -((Lookup::movement<King>(sq, 0) & royaltyKing) != 0);
    }

    constexpr short f1 = White ? -l1 : l1;
    const U64 maskPawn = brd->pawns(!White) & ((brd + f1 - 2)->royalty(White) | (brd + f1 + 2)->royalty(White));

    const U64 royaltyBrawnsLR = (brd + f1)->royalty(White);
    const U64 royaltyBrawnsF = royaltyBrawnsLR | (brd + f1 - 2)->royalty(White) | (brd + f1 + 2)->royalty(White);
    const U64 maskBrawn = brd->bitBoard(!White, Brawn) & (pawnShift<!White, North>(royaltyBrawnsF) | (royaltyBrawnsLR & Not<East>()) << 1 | (royaltyBrawnsLR & Not<West>()) >> 1);

    return maskSlider | maskKnight | maskKing | maskPawn | maskBrawn;
  }

  //template<U8 Set, U16 T, bool White>
  //_Compiletime void travelMasks(Board<Set>* brd, TimelineInfo& info) {
  //  constexpr U16 l1 = T, l2 = 2 * T, l3 = 3 * T, l4 = 4 * T, l5 = 5 * T, l6 = 6 * T, l7 = 7 * T;
//
  //  info.o1 = _mm512_set_epi64(0, (brd - l1 +  2)->board.occ, (brd - l1)->board.occ, (brd - l1 -  2)->board.occ, (brd -  2)->board.occ, (brd + l1 +  2)->board.occ, (brd + l1)->board.occ, (brd + l1 -  2)->board.occ);
  //  info.o2 = _mm512_set_epi64(0, (brd - l2 +  4)->board.occ, (brd - l2)->board.occ, (brd - l2 -  4)->board.occ, (brd -  4)->board.occ, (brd + l2 +  4)->board.occ, (brd + l2)->board.occ, (brd + l2 -  4)->board.occ);
  //  info.o3 = _mm512_set_epi64(0, (brd - l3 +  6)->board.occ, (brd - l3)->board.occ, (brd - l3 -  6)->board.occ, (brd -  6)->board.occ, (brd + l3 +  6)->board.occ, (brd + l3)->board.occ, (brd + l3 -  6)->board.occ);
  //  info.o4 = _mm512_set_epi64(0, (brd - l4 +  8)->board.occ, (brd - l4)->board.occ, (brd - l4 -  8)->board.occ, (brd -  8)->board.occ, (brd + l4 +  8)->board.occ, (brd + l4)->board.occ, (brd + l4 -  8)->board.occ);
  //  info.o5 = _mm512_set_epi64(0, (brd - l5 + 10)->board.occ, (brd - l5)->board.occ, (brd - l5 - 10)->board.occ, (brd - 10)->board.occ, (brd + l5 + 10)->board.occ, (brd + l5)->board.occ, (brd + l5 - 10)->board.occ);
  //  info.o6 = _mm512_set_epi64(0, (brd - l6 + 12)->board.occ, (brd - l6)->board.occ, (brd - l6 - 12)->board.occ, (brd - 12)->board.occ, (brd + l6 + 12)->board.occ, (brd + l6)->board.occ, (brd + l6 - 12)->board.occ);
  //  info.o7 = _mm512_set_epi64(0, (brd - l7 + 14)->board.occ, (brd - l7)->board.occ, (brd - l7 - 14)->board.occ, (brd - 14)->board.occ, (brd + l7 + 14)->board.occ, (brd + l7)->board.occ, (brd + l7 - 14)->board.occ);
//
  //  const U512 c1 = _mm512_set_epi64(0, (brd - l1 +  2)->checkMask, (brd - l1)->checkMask, (brd - l1 -  2)->checkMask, (brd -  2)->checkMask, (brd + l1 +  2)->checkMask, (brd + l1)->checkMask, (brd + l1 -  2)->checkMask);
  //  const U512 c2 = _mm512_set_epi64(0, (brd - l2 +  4)->checkMask, (brd - l2)->checkMask, (brd - l2 -  4)->checkMask, (brd -  4)->checkMask, (brd + l2 +  4)->checkMask, (brd + l2)->checkMask, (brd + l2 -  4)->checkMask);
  //  const U512 c3 = _mm512_set_epi64(0, (brd - l3 +  6)->checkMask, (brd - l3)->checkMask, (brd - l3 -  6)->checkMask, (brd -  6)->checkMask, (brd + l3 +  6)->checkMask, (brd + l3)->checkMask, (brd + l3 -  6)->checkMask);
  //  const U512 c4 = _mm512_set_epi64(0, (brd - l4 +  8)->checkMask, (brd - l4)->checkMask, (brd - l4 -  8)->checkMask, (brd -  8)->checkMask, (brd + l4 +  8)->checkMask, (brd + l4)->checkMask, (brd + l4 -  8)->checkMask);
  //  const U512 c5 = _mm512_set_epi64(0, (brd - l5 + 10)->checkMask, (brd - l5)->checkMask, (brd - l5 - 10)->checkMask, (brd - 10)->checkMask, (brd + l5 + 10)->checkMask, (brd + l5)->checkMask, (brd + l5 - 10)->checkMask);
  //  const U512 c6 = _mm512_set_epi64(0, (brd - l6 + 12)->checkMask, (brd - l6)->checkMask, (brd - l6 - 12)->checkMask, (brd - 12)->checkMask, (brd + l6 + 12)->checkMask, (brd + l6)->checkMask, (brd + l6 - 12)->checkMask);
  //  const U512 c7 = _mm512_set_epi64(0, (brd - l7 + 14)->checkMask, (brd - l7)->checkMask, (brd - l7 - 14)->checkMask, (brd - 14)->checkMask, (brd + l7 + 14)->checkMask, (brd + l7)->checkMask, (brd + l7 - 14)->checkMask);
//
  //  const U512 em1 = _mm512_set_epi64(0, (brd - l1 +  2)->bitBoard(White, NoType), (brd - l1)->bitBoard(White, NoType), (brd - l1 -  2)->bitBoard(White, NoType), (brd -  2)->bitBoard(White, NoType), (brd + l1 +  2)->bitBoard(White, NoType), (brd + l1)->bitBoard(White, NoType), (brd + l1 -  2)->bitBoard(White, NoType));
  //  const U512 em2 = _mm512_set_epi64(0, (brd - l2 +  4)->bitBoard(White, NoType), (brd - l2)->bitBoard(White, NoType), (brd - l2 -  4)->bitBoard(White, NoType), (brd -  4)->bitBoard(White, NoType), (brd + l2 +  4)->bitBoard(White, NoType), (brd + l2)->bitBoard(White, NoType), (brd + l2 -  4)->bitBoard(White, NoType));
  //  const U512 em3 = _mm512_set_epi64(0, (brd - l3 +  6)->bitBoard(White, NoType), (brd - l3)->bitBoard(White, NoType), (brd - l3 -  6)->bitBoard(White, NoType), (brd -  6)->bitBoard(White, NoType), (brd + l3 +  6)->bitBoard(White, NoType), (brd + l3)->bitBoard(White, NoType), (brd + l3 -  6)->bitBoard(White, NoType));
  //  const U512 em4 = _mm512_set_epi64(0, (brd - l4 +  8)->bitBoard(White, NoType), (brd - l4)->bitBoard(White, NoType), (brd - l4 -  8)->bitBoard(White, NoType), (brd -  8)->bitBoard(White, NoType), (brd + l4 +  8)->bitBoard(White, NoType), (brd + l4)->bitBoard(White, NoType), (brd + l4 -  8)->bitBoard(White, NoType));
  //  const U512 em5 = _mm512_set_epi64(0, (brd - l5 + 10)->bitBoard(White, NoType), (brd - l5)->bitBoard(White, NoType), (brd - l5 - 10)->bitBoard(White, NoType), (brd - 10)->bitBoard(White, NoType), (brd + l5 + 10)->bitBoard(White, NoType), (brd + l5)->bitBoard(White, NoType), (brd + l5 - 10)->bitBoard(White, NoType));
  //  const U512 em6 = _mm512_set_epi64(0, (brd - l6 + 12)->bitBoard(White, NoType), (brd - l6)->bitBoard(White, NoType), (brd - l6 - 12)->bitBoard(White, NoType), (brd - 12)->bitBoard(White, NoType), (brd + l6 + 12)->bitBoard(White, NoType), (brd + l6)->bitBoard(White, NoType), (brd + l6 - 12)->bitBoard(White, NoType));
  //  const U512 em7 = _mm512_set_epi64(0, (brd - l7 + 14)->bitBoard(White, NoType), (brd - l7)->bitBoard(White, NoType), (brd - l7 - 14)->bitBoard(White, NoType), (brd - 14)->bitBoard(White, NoType), (brd + l7 + 14)->bitBoard(White, NoType), (brd + l7)->bitBoard(White, NoType), (brd + l7 - 14)->bitBoard(White, NoType));
//
  //  info.m1 = c1 & ~em1;
  //  info.m2 = c2 & ~em2;
  //  info.m3 = c3 & ~em3;
  //  info.m4 = c4 & ~em4;
  //  info.m5 = c5 & ~em5;
  //  info.m6 = c6 & ~em6;
  //  info.m7 = c7 & ~em7;
//
  //  info.b1 = _mm512_set_epi64(0, (brd - l1 +  2)->banMask, (brd - l1)->banMask, (brd - l1 -  2)->banMask, (brd -  2)->banMask, (brd + l1 +  2)->banMask, (brd + l1)->banMask, (brd + l1 -  2)->banMask);
  //  info.b2 = _mm512_set_epi64(0, (brd - l2 +  4)->banMask, (brd - l2)->banMask, (brd - l2 -  4)->banMask, (brd -  4)->banMask, (brd + l2 +  4)->banMask, (brd + l2)->banMask, (brd + l2 -  4)->banMask);
  //  info.b3 = _mm512_set_epi64(0, (brd - l3 +  6)->banMask, (brd - l3)->banMask, (brd - l3 -  6)->banMask, (brd -  6)->banMask, (brd + l3 +  6)->banMask, (brd + l3)->banMask, (brd + l3 -  6)->banMask);
  //  info.b4 = _mm512_set_epi64(0, (brd - l4 +  8)->banMask, (brd - l4)->banMask, (brd - l4 -  8)->banMask, (brd -  8)->banMask, (brd + l4 +  8)->banMask, (brd + l4)->banMask, (brd + l4 -  8)->banMask);
  //  info.b5 = _mm512_set_epi64(0, (brd - l5 + 10)->banMask, (brd - l5)->banMask, (brd - l5 - 10)->banMask, (brd - 10)->banMask, (brd + l5 + 10)->banMask, (brd + l5)->banMask, (brd + l5 - 10)->banMask);
  //  info.b6 = _mm512_set_epi64(0, (brd - l6 + 12)->banMask, (brd - l6)->banMask, (brd - l6 - 12)->banMask, (brd - 12)->banMask, (brd + l6 + 12)->banMask, (brd + l6)->banMask, (brd + l6 - 12)->banMask);
  //  info.b7 = _mm512_set_epi64(0, (brd - l7 + 14)->banMask, (brd - l7)->banMask, (brd - l7 - 14)->banMask, (brd - 14)->banMask, (brd + l7 + 14)->banMask, (brd + l7)->banMask, (brd + l7 - 14)->banMask);
//
  //  info.e1 = _mm512_set_epi64(0, (brd - l1 +  2)->bitBoard(!White, NoType), (brd - l1)->bitBoard(!White, NoType), (brd - l1 -  2)->bitBoard(!White, NoType), (brd -  2)->bitBoard(!White, NoType), (brd + l1 +  2)->bitBoard(!White, NoType), (brd + l1)->bitBoard(!White, NoType), (brd + l1 -  2)->bitBoard(!White, NoType));
  //  info.e2 = _mm512_set_epi64(0, (brd - l2 +  4)->bitBoard(!White, NoType), (brd - l2)->bitBoard(!White, NoType), (brd - l2 -  4)->bitBoard(!White, NoType), (brd -  4)->bitBoard(!White, NoType), (brd + l2 +  4)->bitBoard(!White, NoType), (brd + l2)->bitBoard(!White, NoType), (brd + l2 -  4)->bitBoard(!White, NoType));
  //  info.e3 = _mm512_set_epi64(0, (brd - l3 +  6)->bitBoard(!White, NoType), (brd - l3)->bitBoard(!White, NoType), (brd - l3 -  6)->bitBoard(!White, NoType), (brd -  6)->bitBoard(!White, NoType), (brd + l3 +  6)->bitBoard(!White, NoType), (brd + l3)->bitBoard(!White, NoType), (brd + l3 -  6)->bitBoard(!White, NoType));
  //  info.e4 = _mm512_set_epi64(0, (brd - l4 +  8)->bitBoard(!White, NoType), (brd - l4)->bitBoard(!White, NoType), (brd - l4 -  8)->bitBoard(!White, NoType), (brd -  8)->bitBoard(!White, NoType), (brd + l4 +  8)->bitBoard(!White, NoType), (brd + l4)->bitBoard(!White, NoType), (brd + l4 -  8)->bitBoard(!White, NoType));
  //  info.e5 = _mm512_set_epi64(0, (brd - l5 + 10)->bitBoard(!White, NoType), (brd - l5)->bitBoard(!White, NoType), (brd - l5 - 10)->bitBoard(!White, NoType), (brd - 10)->bitBoard(!White, NoType), (brd + l5 + 10)->bitBoard(!White, NoType), (brd + l5)->bitBoard(!White, NoType), (brd + l5 - 10)->bitBoard(!White, NoType));
  //  info.e6 = _mm512_set_epi64(0, (brd - l6 + 12)->bitBoard(!White, NoType), (brd - l6)->bitBoard(!White, NoType), (brd - l6 - 12)->bitBoard(!White, NoType), (brd - 12)->bitBoard(!White, NoType), (brd + l6 + 12)->bitBoard(!White, NoType), (brd + l6)->bitBoard(!White, NoType), (brd + l6 - 12)->bitBoard(!White, NoType));
  //  info.e7 = _mm512_set_epi64(0, (brd - l7 + 14)->bitBoard(!White, NoType), (brd - l7)->bitBoard(!White, NoType), (brd - l7 - 14)->bitBoard(!White, NoType), (brd - 14)->bitBoard(!White, NoType), (brd + l7 + 14)->bitBoard(!White, NoType), (brd + l7)->bitBoard(!White, NoType), (brd + l7 - 14)->bitBoard(!White, NoType));
  //}

  template<U8 Set, U8 Size, U16 L, U16 T>
  template<bool White>
  _Compiletime void Chess<Set, Size, L, T>::makeMove(const Move& move) {
    Board<Set>& brd = boards[move.sTimeline][move.sTurn + 1];
    brd.board = boards[move.sTimeline][move.sTurn].board;

    switch (move.type) {
    case Normal:       brd.template makeMove<White, Normal      >(move); break;
    case Capture:      brd.template makeMove<White, Capture     >(move); break;
    case Push:         brd.template makeMove<White, Push        >(move); break;
    case Enpassant:    brd.template makeMove<White, Enpassant   >(move); break;
    case Promotion:    brd.template makeMove<White, Promotion   >(move); break;
    case PromoCapture: brd.template makeMove<White, PromoCapture>(move); break;
    case Castle:       brd.template makeMove<White, Castle      >(move); break;
    }
    //travel cases
    if (move.type >= Travel) {

      int newTimeline;
      //increment whiteNum/blackNum/active/otherstuff
      if (timelineInfo[move.eTimeline].turn == move.eTurn) { //Checks if its a jump
        newTimeline = move.eTimeline;
        ++timelineInfo[newTimeline].turn;
      }
      else {
        if (White) {
          newTimeline = whiteOrigIndex - whiteNum - 1;
          whiteNum++;
          if (blackNum >= whiteNum) whiteActiveNum++;
        }
        else {
          newTimeline = blackOrigIndex + blackNum + 1;
          blackNum++;
          if (whiteNum >= blackNum) blackActiveNum++;
        }
        timelineInfo[newTimeline].tailIndex = move.eTurn + 1;
        timelineInfo[newTimeline].turn = move.eTurn + 1;
      }

      Board<Set>& brdTravel = boards[newTimeline][move.eTurn + 1];
      brdTravel.board = boards[move.eTimeline][move.eTurn].board;

      bool promotion = move.type >= TravelPromotion;

      const Piece piece = promotion ? Piece(move.special1) : brd.board.mailboxBoard[move.from];

      const U64 from = 1ull << move.from;
      brd.board.bitBoard[brd.board.mailboxBoard[move.from]] ^= from;
      brd.template bitBoard<White, NoType>() ^= from;
      brd.board.occ ^= from;
      brd.board.unmoved &= ~from;
      brd.board.epTarget = 0;
      brd.board.mailboxBoard[move.from] = NoPiece;

      if (move.type == TravelCapture || move.type == TravelPromoCapture) { brdTravel.template makeMoveTravel<White, true >(move, piece); }
      else { brdTravel.template makeMoveTravel<White, false>(move, piece); }
    }
    ++timelineInfo[move.sTimeline].turn;
  }

  template<U8 Set, U8 Size, U16 L, U16 T>
  template<bool White>
  _Compiletime void Chess<Set, Size, L, T>::undoMove(const Move& move) {//if board saves the timeline it creates you could pass only a timeline index to it
    Board<Set>& brd = boards[move.sTimeline][move.sTurn + 1];
    brd.board.occ = 0xffffffffffffffff;
    if (Set > WKing) brd.template bitBoard<!White, King  >() = 0x0000000000000000;
    if (Set > WRQueen) brd.template bitBoard<!White, RQueen>() = 0x0000000000000000;
    --timelineInfo[move.sTimeline].turn;

    if (move.type >= Travel) {
      int eTimelineReal;  //if stored in brd object can just be taken from there
      if (timelineInfo[move.eTimeline].turn + 1 == move.eTurn) { //timelineInfo[move.eTimeline].createdFrom==move.sTimeline
        eTimelineReal = move.eTimeline;
        --timelineInfo[eTimelineReal].turn;
      }
      else {
        if (White) {
          eTimelineReal = whiteOrigIndex - whiteNum;
          whiteNum--;
          if (blackNum >= whiteNum) whiteActiveNum++;
        }
        else {
          eTimelineReal = blackOrigIndex + blackNum;
          blackNum--;
          if (whiteNum >= blackNum) blackActiveNum++;
        }
        timelineInfo[eTimelineReal].tailIndex = 0; //not really necessary
        timelineInfo[eTimelineReal].turn = 0;
      }
      Board<Set>& brdTo = boards[eTimelineReal][move.eTurn + 1];
      brdTo.board.occ = 0xffffffffffffffff;
      if (Set > WKing) brdTo.template bitBoard<!White, King  >() = 0x0000000000000000;
      if (Set > WRQueen) brdTo.template bitBoard<!White, RQueen>() = 0x0000000000000000;
    }
  }

  template<U8 Set, U8 Size, U16 L, U16 T>
  template<bool White>
  _Compiletime void Chess<Set, Size, L, T>::generateMoves(std::vector<Move>& moves) {
    // Get the board and set up checkMasks, pinMasks, and banMask
    TimelineInfo info = timelineInfo[whiteOrigIndex];
    Board<Set>& brd = boards[whiteOrigIndex][info.turn];
    brd.template refresh<White>(info);
    //travelMasks<Set, T, White>(&brd, info);

    // Change to false to disable past checks
    const U64 pastMask = true ? createMask<Set, T, White>(&brd) : 0x0000000000000000;
    const U64 pastCheckMask = pastMask | -(pastMask == 0);
    const U64 legalMask = brd.checkMask & pastCheckMask;

    if (pastMask == 0x0000000000000000) {
      if (legalMask) brd.template genAllMoves  <Size, White>(moves, info, legalMask, pastCheckMask);
      else           brd.template genRoyalMoves<Size, White>(moves, info, pastCheckMask);
    }
    else if ((pastMask & (pastMask - 1)) == 0x0000000000000000) {
      if (legalMask) brd.template genBitMoves     <Size, White>(moves, info, legalMask, pastCheckMask);
      else           brd.template genRoyalBitMoves<Size, White>(moves, info, pastCheckMask);
    }
  }

  template<U8 Set, U8 Size, U16 L, U16 T>
  template<bool isWhite>
  _Compiletime Move Chess<Set, Size, L, T>::PGNtoMove(std::smatch matches) {

    Move move;
    int score = 0;
    if (matches[1].matched) {
      move.sTimeline = whiteOrigIndex - std::stoi(matches[1].str()); //two timelines
      move.sTurn = 2 * std::stoi(matches[2].str()) + (isWhite ? 16 : 17);
    }
    else {
      move.sTimeline = whiteOrigIndex;
      move.sTurn = timelineInfo[move.sTimeline].turn;
    }

    if (matches[8].matched) {
      move.type = Travel;

      move.eTimeline = whiteOrigIndex - std::stoi(matches[10].str()); //two timelines
      move.eTurn = 2 * std::stoi(matches[11].str()) + (isWhite ? 16 : 17);
      move.from = (Size * (matches[7].str()[1] - '1')) + (matches[7].str()[0] - 'a');
      move.to = (Size * (matches[12].str()[1] - '1')) + (matches[12].str()[0] - 'a');
      U64 lastRank = 0xffull | 0xffull << (8 * Size - 8); //could be issues with having both last ranks
      if ((!matches[3].matched || matches[3].str() == "P" || matches[3].str() == "W") && (lastRank & (1ULL << move.to))) {
        move.special1 = charToPiece(matches[13].str()[0] + (isWhite ? 0 : 32));
        //charToPiece<isWhite>(matches[13].str()[0]);
        move.type = (boards[move.eTimeline][move.eTurn].board.mailboxBoard[move.to] != NoPiece) ? TravelPromoCapture : TravelPromotion;
      }
      else {
        move.type = (boards[move.eTimeline][move.eTurn].board.mailboxBoard[move.to] != NoPiece) ? TravelCapture : Travel;
      }
    }
    else {
      move.type = Normal;
      move.eTimeline = move.sTimeline;
      move.eTurn = move.sTurn;
      move.from = (Size * (matches[6].str()[0] - '1')) + (matches[5].str()[0] - 'a');
      move.to = (Size * (matches[7].str()[1] - '1')) + (matches[7].str()[0] - 'a');
      //Castle Check
      if ((matches[3].str() == "K" && abs(move.to - move.from) == 2)) {
        int i = move.to;
        while (boards[move.eTimeline][move.eTurn].board.mailboxBoard[i] != toPiece(isWhite, Rook) && i<Size * ((move.to / Size) + 1) - 1 && i>Size * (move.to / Size)) {
          if (move.to - move.from > 0) { i++; }
          else { i--; }
        }
        move.special1 = i;
        move.special2 = move.from + ((int)move.to - (int)move.from) / 2;
        move.type = Castle;
      }
      else if (!matches[3].matched || matches[3].str() == "P" || matches[3].str() == "W") {//En Passant/Pawn Push/
        U64 lastRank = 0xffull | 0xffull << (8 * Size - 8); //could be issues with having both last ranks
        if (pawnShift<isWhite, North>(boards[move.eTimeline][move.eTurn].board.epTarget) & (1ULL << move.to)) { //directions could be off need to test
          move.special1 = pawnSquare<!isWhite, North>(move.to);
          move.type = Enpassant;
        }
        else if (lastRank & (1ULL << move.to)) {
          move.special1 = charToPiece(matches[13].str()[0] + (isWhite ? 0 : 32));
          //charToPiece<isWhite>(matches[13].str()[0]);
          move.type = (boards[move.eTimeline][move.eTurn].board.mailboxBoard[move.to] != NoPiece) ? PromoCapture : Promotion;
        }
        else {
          if (boards[move.eTimeline][move.eTurn].board.mailboxBoard[move.to] != NoPiece) {
            move.type = Capture;
          }
          else {
            move.type = (abs(move.to - move.from) == 16) ? Push : Normal;
          }
        }
      }
      else if (boards[move.eTimeline][move.eTurn].board.mailboxBoard[move.to] != NoPiece) {
        move.type = Capture;
      }
      else {
        move.type = Normal;
      }
    }
    return move;
  }

  template<U8 Set, U8 Size, U16 L, U16 T>
  _Compiletime void Chess<Set, Size, L, T>::importPGN(std::string PGN) {
    const std::regex turnPat("(?:\\d+\\.\\s*)(?:\\{[^\\}]*\\}\\s*)?([^\\/]*[^\\/\\s])(?:\\s*[\\/]\\s*)*(?:\\{[^\\}]*\\}\\s*)?(.*[^\\s]|)");
    const std::regex movePat("(?:\\((-?\\d+)T(\\d+)\\))?([KQRBNPUDSWCY])?(([a-h])?([1-8])?)?x?([a-h][1-8])(([>][>]|[>])\\((-?\\d+)T(\\d+)\\)x?([a-h][1-8]))?(?:=([KQRBNPUDSWCY]))?");
    for (auto i = std::sregex_iterator(PGN.begin(), PGN.end(), turnPat); i != std::sregex_iterator(); ++i) {
      const std::string& white = (*i)[1].str();
      for (auto j = std::sregex_iterator(white.begin(), white.end(), movePat); j != std::sregex_iterator(); ++j) {
        makeMove<true>(PGNtoMove<true>(*j));
      }

      const std::string black = (*i)[2].str();
      for (auto j = std::sregex_iterator(black.begin(), black.end(), movePat); j != std::sregex_iterator(); ++j) {
        makeMove<false>(PGNtoMove<false>(*j));
      }
    }
  }
  
  // Fen must have boards in order from least recent to most recent along any given timeline.
  template<U8 Set, U8 Size, U16 L, U16 T>
  _Compiletime void Chess<Set, Size, L, T>::importFen(std::string fen) {
    std::regex boardPat("\\[([^\\/]+)\\/?([^\\/]+)?\\/?([^\\/]+)?\\/?([^\\/]+)?\\/?([^\\/]+)?\\/?([^\\/]+)?\\/?([^\\/]+)\\/?([^\\/]+)?:(\\d+):(-?\\d+):(w|b)\\]");
    std::regex rowPat("([pPnNbBrRqQkKsScCyYwWuUdD]|[1-8])\\s*(\\*)?");
    for (auto i = std::sregex_iterator(fen.begin(), fen.end(), boardPat); i != std::sregex_iterator(); ++i) {
      const std::smatch& board = *i;
      const bool white = board[11].str()[0] == 'w';
      const U8 brdL = stoi(board[9].str()) + whiteOrigIndex;
      const U8 brdT = 2 * stoi(board[10].str()) + (white ? 16 : 17);

      if (brdL < whiteOrigIndex - blackNum) blackNum = whiteOrigIndex - brdL;
      if (brdL > whiteOrigIndex + whiteNum) whiteNum = brdL - whiteOrigIndex;

      Board<Set>& brd = boards[brdL][brdT];
      for (U8 i = 0; i < Size; ++i) {
        const std::string& row = board[i + 1].str();
        U8 sq = 56 - 8 * i;
        for (auto j = std::sregex_iterator(row.begin(), row.end(), rowPat); j != std::sregex_iterator(); ++j) {
          const char ch = j->str()[0];
          if ('1' <= ch && ch <= '8') {
            sq += ch - 48;
          }
          else {
            const Piece piece = charToPiece(ch);
            brd.board.mailboxBoard[sq] = piece;
            brd.board.unmoved |= U64(j->length() == 2) << sq;
            brd.board.bitBoard[piece] |= 1ull << sq++;
          }
        }
      }

      for (U8 p = WPawn; p < Set; p += 2) brd.board.white |= brd.board.bitBoard[p];
      for (U8 p = BPawn; p < Set; p += 2) brd.board.black |= brd.board.bitBoard[p];
      brd.board.occ = brd.board.white | brd.board.black;

      TimelineInfo& info = timelineInfo[brdL];
      info.turn = info.turn == 0 ? brdT : std::min(info.turn, brdT);
      info.tailIndex = std::max(info.tailIndex, brdT);

      Board<Set>& prev = boards[brdL][brdT - 2];
      const U64 royalty = prev.royalty(white);

      brd.pastMask.center = royalty | prev.board.occ & prev.pastMask.center;
      brd.pastMask.north = royalty | prev.board.occ & (prev.pastMask.north) << 8;
      brd.pastMask.east = royalty | prev.board.occ & (prev.pastMask.east & Not<East>()) << 1;
      brd.pastMask.south = royalty | prev.board.occ & (prev.pastMask.south) >> 8;
      brd.pastMask.west = royalty | prev.board.occ & (prev.pastMask.west & Not<West>()) >> 1;
      brd.pastMask.northeast = royalty | prev.board.occ & (prev.pastMask.northeast & Not<East>()) << 9;
      brd.pastMask.southeast = royalty | prev.board.occ & (prev.pastMask.southeast & Not<East>()) >> 7;
      brd.pastMask.southwest = royalty | prev.board.occ & (prev.pastMask.southwest & Not<West>()) >> 9;
      brd.pastMask.northwest = royalty | prev.board.occ & (prev.pastMask.northwest & Not<West>()) << 7;
    }
  }

  template<U8 Set, U8 Size, U16 L, U16 T>
  _Compiletime void Chess<Set, Size, L, T>::printToFile(std::ofstream& file) {
    const U8 top = blackOrigIndex + blackNum;
    const U8 bot = whiteOrigIndex - whiteNum;

    U8 min = timelineInfo[bot].tailIndex;
    for (U8 i = bot; i <= top; ++i) min = std::min(min, timelineInfo[i].tailIndex);

    for (U8 i = top; i >= bot; --i) {
      const U8 tail = timelineInfo[i].tailIndex;
      const U8 head = timelineInfo[i].turn;

      for (U8 j = min; j < tail; ++j) file << "          ";
      for (U8 j = tail; j <= head; ++j) {
        std::string label = std::to_string(whiteOrigIndex - i) + "," + std::to_string((j - 16) / 2);
        file << "╔" + label + std::string("════════", 24 - 3 * label.length()) + "╗";
      }
      file << "\n";

      for (char j = 7; j >= 0; --j) {
        for (U8 k = min; k < tail; ++k) file << "          ";
        for (U8 k = tail; k <= head; ++k) {
          file << "║";
          for (U8 l = 0; l < 8; ++l)  file << pieceToChar(boards[i][k].board.mailboxBoard[j * 8 + l]);
          file << "║";
        }
        file << "\n";
      }

      for (U8 j = min; j < tail; ++j) file << "          ";
      for (U8 j = tail; j <= head; ++j) file << "╚════════╝";
      file << "\n";
    }
  }

  template<U8 Set, U8 Size, U16 L, U16 T>
  _Compiletime std::ostream& operator<<(std::ostream& os, const Chess<Set, Size, L, T>& chess) {
    const int top = chess.blackOrigIndex + chess.blackNum;
    const int bot = chess.whiteOrigIndex - chess.whiteNum;

    int min = chess.timelineInfo[bot].tailIndex;
    int max = chess.timelineInfo[bot].turn;
    for (int i = top; i > bot; --i) {
      min = std::min(min, int(chess.timelineInfo[i].tailIndex));
      max = std::max(max, int(chess.timelineInfo[i].turn));
    }

    for (int i = 0; i < 20; ++i) os << "----------";
    os << "\n";

    for (int i = min; i <= max; i += 20) {
      for (int j = top; j >= bot; --j) {
        const int tail = chess.timelineInfo[j].tailIndex;
        const int head = chess.timelineInfo[j].turn;
        if (i + 19 < tail || i > head) continue;

        const int cur_min = std::max(i, tail);
        const int cur_max = std::min(i + 19, head);

        for (int k = i; k < cur_min; ++k) os << "          ";
        for (int k = cur_min; k <= cur_max; ++k) {
          std::string label = std::to_string(chess.whiteOrigIndex - j) + "," + std::to_string((k - 16) / 2);
          os << "╔" + label + std::string("════════", 24 - 3 * label.length()) + "╗";
        }
        for (int k = cur_max + 1; k < i + 20; ++k) os << "          ";
        os << "\n";

        for (int k = 7; k >= 0; --k) {
          for (int l = i; l < cur_min; ++l) os << "          ";
          for (int l = cur_min; l <= cur_max; ++l) {
            os << "║";
            for (size_t m = 0; m < 8; ++m) os << pieceToChar(chess.boards[j][l].board.mailboxBoard[k * 8 + m]);
            os << "║";
          }
          for (int l = cur_max + 1; l < i + 20; ++l) os << "          ";
          os << "\n";
        }

        for (int k = i; k < cur_min; ++k)          os << "          ";
        for (int k = cur_min; k <= cur_max; ++k)   os << "╚════════╝";
        for (int k = cur_max + 1; k < i + 20; ++k) os << "          ";
        os << "\n";
      }

      for (size_t j = 0; j < 20; ++j) os << "----------";
      os << "\n";
    }

    return os;
  }
};