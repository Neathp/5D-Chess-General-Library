#include <chrono>
#include <algorithm>
#include "chess.hpp"

static U64 count = 0;
static U64 prev = 0;

template<typename Chess>
_Compiletime void evaluate(Chess& chess) {
  ++count;
  //std::cout << chess;
}

template<bool White, typename Chess>
_Compiletime void negaMax(Chess& chess, int alpha, int beta, int depth) {
  if (depth == 0) {evaluate(chess); return;}

  std::vector<Chess5D::Move> moves;
  moves.reserve(40);
  chess.template generateMoves<White>(moves);

  for (const auto& move : moves) {
    chess.template makeMove<White>(move);
    negaMax<!White>(chess, alpha, beta, depth - 1);
    chess.template undoMove<White>(move);
  }
}

int main() {
  // To allow unicode characters
  system("chcp 65001 > nul");

  std::ofstream outputFile("output.txt");

  Chess5D::Chess<Chess5D::NoPiece, 8, 32, 128> chess {};
  std::string fen = "[r*nbqk*bnr*/p*p*p*p*p*p*p*p*/8/8/8/8/P*P*P*P*P*P*P*P*/R*NBQK*BNR*:0:1:w]\n";
  chess.importFen(fen);
  
  std::string pgn="1.{10:03}(0T1)e2e4 / {10:03}(0T1)Ng8f6\n"
  "2.{10:02}(0T2)d2d4 / {10:01}(0T2)e7e6\n"
  "3.{10:01}(0T3)Bc1g5 / {10:01}(0T3)c7c5\n"
  "4.{10:01}(0T4)b2b4 / {10:01}(0T4)c5b4\n"
  "5.{10:01}(0T5)Nb1d2 / {9:52}(0T5)h7h5\n"
  "6.{9:05}(0T6)Bf1b5 / {8:14}(0T6)a7a6\n"
  "7.{9:00}(0T7)Bb5a4 / {7:45}(0T7)b7b5\n"
  "8.{8:59}(0T8)Ba4b3 / {7:34}(0T8)Nb8c6\n"
  "9.{8:27}(0T9)d4d5 / {6:43}(0T9)Nc6d4\n "
  "10.{8:07}(0T10)Ng1e2 / {5:49}(0T10)Bf8c5\n"
  "11.{7:38}(0T11)Ne2d4 / {5:49}(0T11)Bc5d4\n"
  "12.{7:34}(0T12)Nd2f3 / {4:25}(0T12)Bd4f2\n"
  "13.{7:33}(0T13)Ke1f2 / {4:06}(0T13)Nf6e4\n"
  "14.{7:33}(0T14)Kf2e1 / {3:44}(0T14)Ne4g5\n"
  "15.{7:29}(0T15)Qd1d4 / {3:44}(0T15)Ng5f3\n"
  "16.{7:29}(0T16)g2f3 / {3:11}(0T16)Qd8e7\n"
  "17.{6:22}(0T17)d5d6 / {1:55}(0T17)Qe7g5\n"
  "18.{6:15}(0T18)Rh1g1 / {1:19}(0T18)Qg5f6\n"
  "19.{6:02}(0T19)Qd4f6 / {1:19}(0T19)g7f6\n"
  "20.{4:37}(0T20)Ra1c1 / {0:55}(0T20)a6a5\n"
  "21.{4:39}(0T21)c2c4 / {0:40}(0T21)Bc8>>(0T16)c3\n"
  "22.{2:49}(-1T17)Ke1f1 / {0:40}(-1T17)Bc3d4\n"
  "23.{2:35}(-1T18)h2h4 / {0:34}(-1T18)Qd8f6\n"
  "24.{2:26}(-1T19)Rh1h3 / {0:25}(-1T19)Bd4f2\n"
  "25.{2:25}(-1T20)Kf1f2 / {0:24}(-1T20)Qf6d4\n"
  "26.{1:48}(-1T21)Kf2g2 / {0:23}(-1T21)Rh8h6\n";

std::string pgn2="1.{0:09}(0T1)Ng1f3 / {0:56}(0T1)Ng8f6\n"
  "2.{0:09}(0T2)d2d4 / {0:56}(0T2)e7e6\n"
  "3.{0:09}(0T3)c2c3 / {0:56}(0T3)Qd8e7\n"
  "4.{0:09}(0T4)Bc1g5 / {0:56}(0T4)c7c5\n"
  "5.{0:09}(0T5)d4d5 / {0:56}(0T5)Qe7d6\n"
  "6.{0:09}(0T6)Nb1a3 / {0:56}(0T6)Qd6d5\n"
  "7.{0:09}(0T7)Qd1d5 / {0:56}(0T7)Nf6d5\n"
  "8.{0:09}(0T8)Na3b5 / {0:56}(0T8)f7f6\n"
  "9.{0:09}(0T9)Bg5h4 / {0:56}(0T9)a7a6\n"
  "10.{0:09}(0T10)Nb5a3 / {0:56}(0T10)Nb8c6\n"
  "11.{0:09}(0T11)Bh4g3 / {0:56}(0T11)b7b5\n"
  "12.{0:09}(0T12)Ra1d1 / {0:56}(0T12)Nc6b4\n"
  "13.{0:09}(0T13)c3b4 / {0:56}(0T13)c5b4\n"
  "14.{0:09}(0T14)Na3c2 / {0:56}(0T14)Nd5b6\n"
  "15.{0:09}(0T15)b2b3 / {0:56}(0T15)a6a5\n"
  "16.{0:09}(0T16)e2e3 / {0:56}(0T16)a5a4\n"
  "17.{0:09}(0T17)Bf1b5 / {0:56}(0T17)a4b3\n"
  "18.{0:09}(0T18)Nc2d4 / {0:56}(0T18)Ke8f7\n"
  "19.{0:09}(0T19)Nd4f5 / {0:56}(0T19)e6f5\n"
  "20.{0:09}(0T20)Nf3>>(0T19)f5 / {0:56}(0T20)Bc8>>(0T15)c3\n"
  "21.{0:09}(-1T16)Nf3d2 / {0:56}(-1T16)Nb6d5\n"
  "22.{0:09}(-1T17)e2e3 / {0:56}(-1T17)Bc3d2\n"
  "23.{0:09}(-1T18)Ke1d2 / {0:56}(-1T18)Bf8c5\n"
  "24.{0:09}(-1T19)Bf1c4 / {0:56}(-1T19)Nd5e3 (1T19)e6f5\n"
  "25.{0:09}(-1T20)f2e3 (1T20)Nd4f5 / {0:56}(-1T20)Bc5>>(-1T19)c4\n"
  "26.{0:09}(-2T20)b3c4 / {0:56}(-2T20)Bc5>(1T20)f5\n"
  "27.{0:09}(1T21)Nf3>(0T21)f5 (-1T21)Bc4e6 (-2T21)Bg3c7";

  chess.importPGN(pgn2);
  std::cout << chess;
  chess.printToFile(outputFile);
/*
  auto begin = std::chrono::high_resolution_clock::now();
  negaMax<true>(chess, 0, 0, 6);
  auto end = std::chrono::high_resolution_clock::now();
  std::cout << std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count()/1000000000.0 << " s\n";

  std::cout << count << "\n";
*/
  return 0;
}